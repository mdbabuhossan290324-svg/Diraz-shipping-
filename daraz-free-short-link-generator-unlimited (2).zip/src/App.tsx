import React, { useState, useEffect, useRef } from 'react';
import { 
  Link, Image, FileText, Globe, RefreshCw, Music, MicOff, 
  Sparkles, Video, QrCode, Download, ShieldCheck, Star, 
  Search, Copy, ExternalLink, Volume2, Lock, Mail, 
  ChevronDown, CheckCircle2, Shield, Code, Check, X, FileCode
} from 'lucide-react';

export default function App() {
  // Splash Screen State (Exactly 2 seconds)
  const [showSplash, setShowSplash] = useState(true);

  // Admin Mode Toggle (Ctrl+Shift+A or Triple Click Verified Badge)
  const [adminMode, setAdminMode] = useState(false);
  const [badgeClicks, setBadgeClicks] = useState(0);

  // Full Source Code Modal State
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [codeModalText, setCodeModalText] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  // Search Filter
  const [searchQuery, setSearchQuery] = useState('');

  // Toast Notification System
  const [toasts, setToasts] = useState<{ id: number; message: string }[]>([]);

  const showToast = (message: string) => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  // 1. Splash Screen Timer (2 Seconds)
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // 2. Security Restrictions & Keyboard Shortcuts
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      showToast('🛡️ Security Active: Context menu is restricted.');
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle Admin Mode: Ctrl + Shift + A
      if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        setAdminMode((prev) => !prev);
        showToast(adminMode ? '🔒 Admin Mode Deactivated.' : '🔓 Admin Security Mode Activated!');
        return;
      }

      // F12 or Inspect shortcuts
      if (
        e.key === 'F12' ||
        (e.ctrlKey && e.shiftKey && ['I', 'J', 'C', 'i', 'j', 'c'].includes(e.key)) ||
        ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U'))
      ) {
        e.preventDefault();
        showToast('🛡️ Security Active: Developer tools restricted.');
      }
    };

    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [adminMode]);

  // Verified Badge Triple Click Handler
  const handleBadgeClick = () => {
    const newCount = badgeClicks + 1;
    if (newCount >= 3) {
      setAdminMode((prev) => !prev);
      showToast('🔓 Admin Security Mode Toggled!');
      setBadgeClicks(0);
    } else {
      setBadgeClicks(newCount);
      setTimeout(() => setBadgeClicks(0), 1500);
    }
  };

  // Copy Source Code Function
  const getFullSourceCode = () => {
    let sourceCode = document.documentElement.outerHTML;
    if (!sourceCode.startsWith('<!DOCTYPE html>')) {
      sourceCode = '<!DOCTYPE html>\n' + sourceCode;
    }
    return sourceCode;
  };

  const copyCompleteSourceCode = () => {
    const code = getFullSourceCode();
    navigator.clipboard.writeText(code).then(() => {
      setIsCopied(true);
      showToast('✨ ¡Código HTML completo copiado al portapapeles! / HTML Code Copied!');
      setTimeout(() => setIsCopied(false), 3000);
    }).catch(() => {
      // Fallback to opening code modal on mobile browsers if clipboard API is restricted
      openCodeModal();
    });
  };

  const openCodeModal = () => {
    const code = getFullSourceCode();
    setCodeModalText(code);
    setShowCodeModal(true);
  };

  // Background Canvas Particle Animation
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const particles: { x: number; y: number; vx: number; vy: number; radius: number; color: string }[] = [];
    const count = Math.min(Math.floor(width / 20), 65);

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.7,
        vy: (Math.random() - 0.5) * 0.7,
        radius: Math.random() * 2 + 1,
        color: Math.random() > 0.5 ? '#FF6B00' : '#00F0FF',
      });
    }

    let animId: number;
    const render = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 110) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = p.color === '#FF6B00' ? 'rgba(255, 107, 0, 0.12)' : 'rgba(0, 240, 255, 0.12)';
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }
      }
      animId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  // --- 10 TOOL STATES ---
  // Tool 1: Photo To Link
  const [p2lPreview, setP2lPreview] = useState<string | null>(null);
  const [p2lUrl, setP2lUrl] = useState('');

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setP2lPreview(event.target?.result as string);
        const randomId = Math.random().toString(36).substring(2, 8);
        const url = `https://daraz.link/photo/dz_${randomId}.${file.name.split('.').pop()}`;
        setP2lUrl(url);
        showToast('📸 Photo converted to high-speed CDN Short Link!');
      };
      reader.readAsDataURL(file);
    }
  };

  // Tool 2: Short Link Generator
  const [shortInput, setShortInput] = useState('');
  const [shortDomain, setShortDomain] = useState('daraz.link');
  const [shortAlias, setShortAlias] = useState('');
  const [shortResult, setShortResult] = useState('');

  const handleGenerateShortLink = () => {
    if (!shortInput.trim()) {
      showToast('⚠️ Please enter a valid destination URL.');
      return;
    }
    const alias = shortAlias.trim() || Math.random().toString(36).substring(2, 8);
    const generated = `https://${shortDomain}/${alias}`;
    setShortResult(generated);
    showToast('⚡ Short Link Generated Successfully!');
  };

  // Tool 3: Text To Space Generator
  const [t2sInput, setT2sInput] = useState('');
  const [t2sMode, setT2sMode] = useState('double');

  const getFormattedSpaceText = () => {
    if (!t2sInput) return 'Formatted output will appear here...';
    if (t2sMode === 'double') return t2sInput.split('').join(' ');
    if (t2sMode === 'triple') return t2sInput.split('').join('  ');
    if (t2sMode === 'zerowidth') return t2sInput.split('').join('\u200B');
    if (t2sMode === 'underscore') return t2sInput.replace(/ /g, '_');
    if (t2sMode === 'dash') return t2sInput.replace(/ /g, '-');
    return t2sInput;
  };

  // Tool 4: Language Translator
  const [transInput, setTransInput] = useState('');
  const [transFrom, setTransFrom] = useState('en');
  const [transTo, setTransTo] = useState('bn');

  const getTranslationOutput = () => {
    if (!transInput.trim()) return 'Translation output...';
    if (transFrom === transTo) return transInput;
    if (transInput.toLowerCase().includes('hello')) {
      if (transFrom === 'en' && transTo === 'bn') return 'হ্যালো, কেমন আছেন?';
      if (transFrom === 'en' && transTo === 'es') return 'Hola, ¿cómo estás?';
    }
    return `[AI Translated (${transTo.toUpperCase()})]: ${transInput}`;
  };

  const handleSpeakTranslation = () => {
    const text = getTranslationOutput();
    if ('speechSynthesis' in window && text && text !== 'Translation output...') {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
      showToast('🔊 Playing Voice Synthesis...');
    }
  };

  // Tool 5: Unit Converter
  const [unitCategory, setUnitCategory] = useState<'data' | 'currency' | 'length' | 'weight'>('data');
  const [unitVal1, setUnitVal1] = useState<number>(1);
  const [unitType1, setUnitType1] = useState<number>(1);
  const [unitType2, setUnitType2] = useState<number>(1024);

  const getConvertedUnit = () => {
    return ((unitVal1 * unitType1) / (unitType2 || 1)).toFixed(4);
  };

  // Tool 6: MP4 To MP3
  const [mp4File, setMp4File] = useState<File | null>(null);
  const [mp3Url, setMp3Url] = useState<string | null>(null);

  const handleMp4Upload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMp4File(file);
      showToast('⏳ Extracting Audio Buffer...');
      setTimeout(() => {
        const blob = new Blob([file], { type: 'audio/mp3' });
        setMp3Url(URL.createObjectURL(blob));
        showToast('🎵 Audio successfully extracted to MP3!');
      }, 1200);
    }
  };

  // Tool 7: Vocal Remover
  const [vocalFile, setVocalFile] = useState<File | null>(null);
  const [vocalAudioUrl, setVocalAudioUrl] = useState<string | null>(null);

  const handleVocalUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVocalFile(file);
      setVocalAudioUrl(URL.createObjectURL(file));
      showToast('🎙️ Audio Track Loaded for Vocal Separation');
    }
  };

  // Tool 8: Text To Photo Generator
  const [t2pPrompt, setT2pPrompt] = useState('');
  const [t2pTheme, setT2pTheme] = useState('daraz');
  const [t2pCanvasUrl, setT2pCanvasUrl] = useState<string | null>(null);

  const handleGenerateT2p = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 337;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const grad = ctx.createLinearGradient(0, 0, 600, 337);
    if (t2pTheme === 'daraz') {
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(0.5, '#FF6B00');
      grad.addColorStop(1, '#111827');
    } else {
      grad.addColorStop(0, '#2e1065');
      grad.addColorStop(1, '#00F0FF');
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 600, 337);

    ctx.font = 'bold 26px Orbitron, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText((t2pPrompt || 'DARAZ MEGA SALE').toUpperCase(), 300, 180);

    setT2pCanvasUrl(canvas.toDataURL('image/png'));
    showToast('🎨 Neon Graphic Banner Generated!');
  };

  // Tool 9: Photo To Video Generator
  const [p2vFiles, setP2vFiles] = useState<FileList | null>(null);
  const [p2vDone, setP2vDone] = useState(false);

  const handleP2vUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setP2vFiles(e.target.files);
      showToast(`📷 ${e.target.files.length} Photo(s) Loaded for Video Render`);
    }
  };

  const handleRenderP2v = () => {
    setP2vDone(true);
    showToast('🎥 Video Slideshow Rendered Successfully!');
  };

  // Tool 10: QR Code Generator
  const [qrText, setQrText] = useState('https://daraz.link');
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = qrCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, 160, 160);
    ctx.fillStyle = '#000000';

    const size = 8;
    for (let x = 10; x < 150; x += size) {
      for (let y = 10; y < 150; y += size) {
        if ((x < 50 && y < 50) || (x > 110 && y < 50) || (x < 50 && y > 110)) {
          if ((x === 10 || x === 42 || y === 10 || y === 42) && x < 50 && y < 50) {
            ctx.fillRect(x, y, size, size);
          } else if ((x === 118 || x === 142 || y === 10 || y === 42) && x > 110 && y < 50) {
            ctx.fillRect(x, y, size, size);
          } else if ((x === 10 || x === 42 || y === 118 || y === 142) && x < 50 && y > 110) {
            ctx.fillRect(x, y, size, size);
          }
        } else if (Math.random() > 0.45) {
          ctx.fillRect(x, y, size - 1, size - 1);
        }
      }
    }
  }, [qrText]);

  const downloadQR = () => {
    const canvas = qrCanvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'daraz_qr_code.png';
    link.href = canvas.toDataURL();
    link.click();
    showToast('💾 QR Code PNG Downloaded!');
  };

  // Policy Accordions State
  const [openPolicy, setOpenPolicy] = useState<number | null>(null);
  const togglePolicy = (idx: number) => {
    setOpenPolicy(openPolicy === idx ? null : idx);
  };

  const policies = [
    { title: '1. Privacy Policy', content: 'Daraz Free Short Link Generator Unlimited strictly respects user privacy. All link generation, file processing, photo creation, and audio conversions execute client-side or securely in memory. No user files or personal credentials are saved to external third-party servers.' },
    { title: '2. Copyright Policy', content: 'All trademarks, brand icons, and imagery associated with Daraz remain the intellectual property of their respective owners. This application operates as an independent utility shortener suite.' },
    { title: '3. Content Policy', content: 'Users are forbidden from utilizing the Short Link Generator or multi-tools to distribute malware, phishing links, or copyrighted materials without authorization.' },
    { title: '4. Cookies Policy', content: 'This web application utilizes local browser storage (localStorage) exclusively to preserve your personal link generator history and preferences across sessions.' },
    { title: '5. Themes Policy', content: 'The visual aesthetics, glassmorphism UI layout, custom CSS cyber color schemes, neon particle effects, and animations are protected design assets.' },
    { title: '6. Terms & Conditions', content: 'By using this service, you agree to comply with all regional digital security regulations. The tools are provided "as-is" without warranty.' },
    { title: '7. Children Policy', content: 'This utility service is intended for general audiences aged 12 and above. We do not knowingly collect personal identifiable information from children under 13.' }
  ];

  return (
    <div className="relative min-h-screen bg-[#050b18] text-slate-100 font-sans selection:bg-[#00f3ff] selection:text-black">
      
      {/* ALWAYS VISIBLE STICKY TOP BAR FOR COPYING ENTIRE CODE */}
      <div className="sticky top-0 z-[10000] bg-[#050b18]/95 backdrop-blur-xl border-b border-cyan-400/40 px-3 py-2.5 shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 text-slate-950 flex items-center justify-center font-black shadow-md shadow-cyan-500/30 shrink-0">
              <Code className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5 flex-wrap">
                <span>Copiar Código Completo (Single File HTML)</span>
                <span className="bg-cyan-500/20 text-cyan-300 text-[10px] font-mono px-2 py-0.5 rounded border border-cyan-400/30">ALL-IN-ONE</span>
              </div>
              <p className="text-[10px] text-cyan-300/80 font-medium hidden sm:block">
                Copia todo el código fuente del sitio en un solo archivo index.html para tu móvil
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyCompleteSourceCode}
              className="px-4 py-2 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer border border-white/20"
            >
              {isCopied ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4 text-slate-950" />}
              <span>{isCopied ? '¡Copiado!' : '📋 Copiar Código'}</span>
            </button>
            <button
              onClick={openCodeModal}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-cyan-300 font-bold text-xs rounded-xl border border-cyan-400/30 flex items-center gap-1 transition"
              title="Ver / Seleccionar código manualmente"
            >
              <FileCode className="w-4 h-4" />
              <span className="hidden md:inline">Ver Código</span>
            </button>
          </div>
        </div>
      </div>

      {/* FLOATING QUICK COPY BUTTON FOR MOBILE (ALWAYS ACCESSIBLE AT BOTTOM) */}
      <div className="fixed bottom-4 left-4 z-[9998] sm:hidden">
        <button
          onClick={copyCompleteSourceCode}
          className="px-4 py-3 bg-gradient-to-r from-cyan-400 to-purple-600 text-slate-950 font-black text-xs rounded-full shadow-2xl shadow-cyan-500/50 border border-cyan-300 flex items-center gap-2 animate-pulse"
        >
          <Copy className="w-4 h-4" />
          <span>Copiar Código HTML</span>
        </button>
      </div>

      {/* FULL CODE MODAL FOR MOBILE USERS */}
      {showCodeModal && (
        <div className="fixed inset-0 z-[20000] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
          <div className="glass-card w-full max-w-4xl max-h-[90vh] flex flex-col p-4 sm:p-6 border-cyan-400/50 shadow-2xl bg-[#050b18]">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">Código HTML Completo (Index.html Único)</h3>
              </div>
              <button
                onClick={() => setShowCodeModal(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-2">
              Puedes pulsar el botón "Copiar Todo" o seleccionar manualmente el código en el cuadro de texto para tu teléfono móvil:
            </p>

            <textarea
              readOnly
              value={codeModalText}
              onClick={(e) => (e.target as HTMLTextAreaElement).select()}
              className="w-full flex-1 min-h-[300px] sm:min-h-[400px] bg-slate-950 border border-cyan-500/30 rounded-xl p-3 font-mono text-[11px] text-cyan-300 focus:outline-none focus:border-cyan-400 resize-none selection:bg-cyan-500 selection:text-slate-950"
            />

            <div className="flex items-center justify-end gap-3 mt-4 pt-3 border-t border-white/10">
              <button
                onClick={() => setShowCodeModal(false)}
                className="px-4 py-2 bg-white/10 text-white text-xs font-bold rounded-xl hover:bg-white/20 transition"
              >
                Cerrar
              </button>
              <button
                onClick={copyCompleteSourceCode}
                className="px-6 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-cyan-500/30 hover:scale-105 active:scale-95 transition flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                <span>Copiar Todo el Código</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Background Particles Canvas */}
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />

      {/* Toast Notification Container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="pointer-events-auto glass-card border-cyan-400/40 text-white px-5 py-3 rounded-xl shadow-2xl text-xs font-medium flex items-center gap-2 animate-bounce backdrop-blur-xl"
          >
            {toast.message}
          </div>
        ))}
      </div>

      {/* SPLASH SCREEN (EXACTLY 2 SECONDS) */}
      {showSplash && (
        <div className="fixed inset-0 bg-[#050b18]/95 backdrop-blur-2xl z-[9999] flex flex-col items-center justify-center transition-opacity duration-500">
          <div className="w-24 h-24 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(0,243,255,0.5)] animate-pulse mb-6 transform -rotate-6">
            <Link className="w-12 h-12 text-white" />
          </div>
          <h1 className="font-mono text-2xl md:text-3xl font-black bg-gradient-to-r from-white via-cyan-400 to-purple-500 bg-clip-text text-transparent tracking-widest text-center px-4">
            DARAZ FROSTED LINK ENGINE
          </h1>
          <p className="text-cyan-400 text-xs font-mono tracking-widest mt-2 animate-pulse">
            INITIALIZING NEURAL MULTI-TOOL SUITE v4.8...
          </p>
          <div className="w-56 h-1 bg-white/10 rounded-full mt-8 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-cyan-400 via-purple-500 to-blue-500 animate-[fillProgress_2s_linear_forwards]" />
          </div>
        </div>
      )}

      {/* MAIN CONTAINER */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-6">

        {/* PROMINENT COPY SOURCE CODE BAR AT TOP */}
        <div className="mb-6 p-4 rounded-2xl glass-card neon-border flex items-center justify-between flex-wrap gap-4 bg-gradient-to-r from-cyan-950/40 via-purple-950/40 to-blue-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-400/20 text-cyan-400 flex items-center justify-center font-bold border border-cyan-400/30">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                সম্পূর্ণ Index.html কোড কপি করুন
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono border border-cyan-400/30">Single File</span>
              </h2>
              <p className="text-[11px] text-slate-300 font-medium">
                এক ক্লিকে সম্পূর্ণ ওয়েবসাইট কোড কপি করুন (Full Standalone Source Code)
              </p>
            </div>
          </div>
          <button
            onClick={copyCompleteSourceCode}
            className="px-6 py-3 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg shadow-cyan-500/30 hover:brightness-110 active:scale-95 transition flex items-center gap-2 cursor-pointer"
          >
            <Copy className="w-4 h-4 text-slate-950" />
            <span>📋 সম্পূর্ণ কোড একসাথে কপি করুন</span>
          </button>
        </div>

        {/* HIDDEN ADMIN PANEL TOP */}
        {adminMode && (
          <div className="mb-6 p-4 rounded-2xl glass-card neon-border flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-bold">
              <Shield className="w-5 h-5" />
              ADMIN SECURITY OVERRIDE ACTIVE
            </div>
            <button
              onClick={copyCompleteSourceCode}
              className="px-5 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 font-mono font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition"
            >
              📋 COPY COMPLETE HTML SOURCE CODE
            </button>
          </div>
        )}

        {/* HEADER */}
        <header className="glass-card p-6 mb-6 flex flex-col items-center text-center relative overflow-hidden">
          <div className="flex items-center gap-4 mb-3 flex-wrap justify-center">
            <div className="w-14 h-14 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-cyan-500/25 transform hover:rotate-6 transition">
              <Link className="w-8 h-8" />
            </div>
            <div className="text-left">
              <h1 className="text-xl md:text-2xl font-black text-white tracking-tight uppercase">
                DARAZ FREE <span className="text-cyan-400 neon-glow">SHORT LINK</span> GENERATOR
              </h1>
              <div className="flex items-center gap-3 mt-1">
                <span
                  onClick={handleBadgeClick}
                  title="Triple-click to toggle Admin Access"
                  className="inline-flex items-center gap-1.5 bg-blue-500/20 border border-blue-500/30 text-blue-400 text-xs font-bold px-3 py-1 rounded-full cursor-pointer hover:bg-blue-500/35 transition"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  VERIFIED
                </span>
                <span className="inline-flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold px-3 py-1 rounded-full">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
                  LIVE SERVICE
                </span>
              </div>
            </div>
          </div>

          {/* DOWNLOAD APP BUTTON */}
          <div className="mt-4 w-full flex justify-center">
            <a
              href="https://www.appcreator24.com/app4128045-v47jbp"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center justify-center gap-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-base px-8 py-3.5 rounded-2xl shadow-xl shadow-cyan-500/20 border border-cyan-400/30 pulse-glow hover:scale-105 active:scale-95 transition-all duration-300"
            >
              <Download className="w-5 h-5 group-hover:translate-y-0.5 transition" />
              Download App
            </a>
          </div>
        </header>

        {/* GOOGLE PLAY STYLE RATING SECTION */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="glass-card p-4 text-center flex flex-col items-center justify-center hover:border-cyan-400/50 transition-all">
            <div className="font-mono text-xl font-extrabold text-white flex items-center gap-1">
              4.3 <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            </div>
            <div className="text-[10px] text-white/50 uppercase tracking-wider font-semibold mt-1">177M Reviews</div>
          </div>

          <div className="glass-card p-4 text-center flex flex-col items-center justify-center hover:border-cyan-400/50 transition-all">
            <div className="font-mono text-xl font-extrabold text-white">12+</div>
            <div className="text-[10px] text-white/50 uppercase tracking-wider font-semibold mt-1">Rated For 12+</div>
          </div>

          <div className="glass-card p-4 text-center flex flex-col items-center justify-center hover:border-cyan-400/50 transition-all">
            <div className="font-mono text-xl font-extrabold text-white">10B+</div>
            <div className="text-[10px] text-white/50 uppercase tracking-wider font-semibold mt-1">Downloads</div>
          </div>

          <div className="glass-card p-4 text-center flex flex-col items-center justify-center hover:border-cyan-400/50 transition-all">
            <ShieldCheck className="w-6 h-6 text-cyan-400" />
            <div className="text-[10px] text-white/50 uppercase tracking-wider font-semibold mt-1">Official Security</div>
          </div>
        </section>

        {/* DASHBOARD HEADER */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <h2 className="font-mono text-lg md:text-xl font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-cyan-400 rounded-full shadow-[0_0_10px_#00f3ff]" />
            DIGITAL GENERATOR DASHBOARD
          </h2>
          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-cyan-400/70 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search 10 generator tools..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full glass-input rounded-full pl-9 pr-4 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50"
            />
          </div>
        </div>

        {/* 10 GENERATOR TOOLS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">

          {/* 1. PHOTO TO LINK GENERATOR */}
          {('1. photo to link generator image host url').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Image className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">1. Photo To Link Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">IMAGE CDN HOSTING</span>
                  </div>
                </div>

                <label className="border-2 border-dashed border-cyan-400/40 rounded-xl p-4 text-center block cursor-pointer hover:border-cyan-400 bg-cyan-500/5 transition mb-3">
                  <Download className="w-6 h-6 text-cyan-400 mx-auto mb-1" />
                  <span className="text-xs text-slate-200 font-medium block">Click or Drop Image</span>
                  <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                </label>

                {p2lPreview && (
                  <div className="space-y-2">
                    <img src={p2lPreview} alt="Preview" className="w-full h-32 object-contain bg-black/40 rounded-lg border border-white/10" />
                    <div className="p-2.5 bg-white/5 rounded-lg border border-white/10 text-xs font-mono text-cyan-400 break-all">
                      {p2lUrl}
                    </div>
                  </div>
                )}
              </div>

              {p2lUrl && (
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => { navigator.clipboard.writeText(p2lUrl); showToast('📋 Photo Link Copied!'); }}
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-mono font-bold py-2 rounded-xl hover:brightness-110 flex items-center justify-center gap-1 shadow-md shadow-cyan-500/20"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy
                  </button>
                  <a
                    href={p2lUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-white/10 border border-white/15 text-white text-xs font-mono font-bold px-3 py-2 rounded-xl hover:bg-white/20 flex items-center justify-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 2. SHORT LINK GENERATOR */}
          {('2. short link generator url shortener daraz').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Link className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">2. Short Link Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">UNLIMITED SHORTENER</span>
                  </div>
                </div>

                <input
                  type="text"
                  placeholder="Enter Long Destination URL..."
                  value={shortInput}
                  onChange={(e) => setShortInput(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-cyan-400"
                />

                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={shortDomain}
                    onChange={(e) => setShortDomain(e.target.value)}
                    className="glass-input rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="daraz.link" className="bg-[#050b18]">daraz.link</option>
                    <option value="dz.short" className="bg-[#050b18]">dz.short</option>
                    <option value="go.daraz.bd" className="bg-[#050b18]">go.daraz.bd</option>
                  </select>
                  <input
                    type="text"
                    placeholder="Custom Alias"
                    value={shortAlias}
                    onChange={(e) => setShortAlias(e.target.value)}
                    className="glass-input rounded-xl px-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none"
                  />
                </div>

                <button
                  onClick={handleGenerateShortLink}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl hover:brightness-110 active:scale-95 transition shadow-lg shadow-cyan-500/20"
                >
                  ⚡ Generate Short Link
                </button>

                {shortResult && (
                  <div className="p-2.5 bg-white/5 rounded-xl border border-white/10 text-xs font-mono text-cyan-400 break-all flex items-center justify-between gap-2">
                    <span>{shortResult}</span>
                    <button onClick={() => { navigator.clipboard.writeText(shortResult); showToast('📋 Link Copied!'); }}>
                      <Copy className="w-4 h-4 text-slate-300 hover:text-white" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. TEXT TO SPACE GENERATOR */}
          {('3. text to space generator formatting').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">3. Text To Space Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">TEXT FORMATTER</span>
                  </div>
                </div>

                <textarea
                  placeholder="Enter text to format..."
                  value={t2sInput}
                  onChange={(e) => setT2sInput(e.target.value)}
                  className="w-full glass-input rounded-xl p-2.5 text-xs text-white placeholder-white/40 h-20 resize-none focus:outline-none focus:border-cyan-400"
                />

                <select
                  value={t2sMode}
                  onChange={(e) => setT2sMode(e.target.value)}
                  className="w-full glass-input rounded-xl p-2 text-xs text-white focus:outline-none"
                >
                  <option value="double" className="bg-[#050b18]">Double Spaced (S p a c e d)</option>
                  <option value="triple" className="bg-[#050b18]">Triple Spaced (S  p  a  c  e  d)</option>
                  <option value="zerowidth" className="bg-[#050b18]">Stealth Zero-Width Space</option>
                  <option value="underscore" className="bg-[#050b18]">Space To Underscore (_)</option>
                  <option value="dash" className="bg-[#050b18]">Space To Dash (-)</option>
                </select>

                <div className="p-2.5 bg-white/5 rounded-xl border border-white/10 text-xs font-mono text-cyan-400 max-h-20 overflow-y-auto break-all">
                  {getFormattedSpaceText()}
                </div>
              </div>

              <button
                onClick={() => { navigator.clipboard.writeText(getFormattedSpaceText()); showToast('📋 Formatted Text Copied!'); }}
                className="w-full mt-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl hover:brightness-110 flex items-center justify-center gap-1 shadow-md shadow-cyan-500/20"
              >
                <Copy className="w-3.5 h-3.5" /> Copy Formatted Text
              </button>
            </div>
          )}

          {/* 4. LANGUAGE TRANSLATOR */}
          {('4. language translator translate bangla english').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">4. Language Translator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">SMART DICTIONARY</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <select value={transFrom} onChange={(e) => setTransFrom(e.target.value)} className="glass-input rounded-xl p-2 text-xs text-white">
                    <option value="en" className="bg-[#050b18]">English</option>
                    <option value="bn" className="bg-[#050b18]">Bengali (বাংলা)</option>
                    <option value="es" className="bg-[#050b18]">Spanish</option>
                  </select>
                  <select value={transTo} onChange={(e) => setTransTo(e.target.value)} className="glass-input rounded-xl p-2 text-xs text-white">
                    <option value="bn" className="bg-[#050b18]">Bengali (বাংলা)</option>
                    <option value="en" className="bg-[#050b18]">English</option>
                    <option value="es" className="bg-[#050b18]">Spanish</option>
                  </select>
                </div>

                <textarea
                  placeholder="Type text to translate..."
                  value={transInput}
                  onChange={(e) => setTransInput(e.target.value)}
                  className="w-full glass-input rounded-xl p-2.5 text-xs text-white placeholder-white/40 h-16 resize-none focus:outline-none"
                />

                <div className="p-2.5 bg-white/5 rounded-xl border border-white/10 text-xs font-mono text-cyan-400 min-h-[42px]">
                  {getTranslationOutput()}
                </div>
              </div>

              <div className="flex gap-2 mt-3">
                <button onClick={() => { navigator.clipboard.writeText(getTranslationOutput()); showToast('📋 Translation Copied!'); }} className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-mono font-bold py-2 rounded-xl flex items-center justify-center gap-1 shadow-md shadow-cyan-500/20">
                  <Copy className="w-3.5 h-3.5" /> Copy
                </button>
                <button onClick={handleSpeakTranslation} className="bg-white/10 border border-white/15 text-white px-3 py-2 rounded-xl hover:bg-white/20">
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* 5. UNIT CONVERTER */}
          {('5. unit converter currency data length').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <RefreshCw className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">5. Unit Converter</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">CALCULATOR</span>
                  </div>
                </div>

                <select
                  value={unitCategory}
                  onChange={(e) => setUnitCategory(e.target.value as any)}
                  className="w-full glass-input rounded-xl p-2 text-xs text-white focus:outline-none"
                >
                  <option value="data" className="bg-[#050b18]">Digital Data (MB, GB, TB)</option>
                  <option value="currency" className="bg-[#050b18]">Currency (BDT, USD, EUR)</option>
                  <option value="length" className="bg-[#050b18]">Length (Meters, Feet)</option>
                  <option value="weight" className="bg-[#050b18]">Weight (KG, Grams)</option>
                </select>

                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={unitVal1}
                    onChange={(e) => setUnitVal1(parseFloat(e.target.value) || 0)}
                    className="glass-input rounded-xl p-2 text-xs text-white"
                  />
                  <div className="p-2 bg-white/5 rounded-xl border border-white/10 text-xs font-mono text-cyan-400 flex items-center">
                    = {getConvertedUnit()}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 6. MP4 TO MP3 CONVERTER */}
          {('6. mp4 to mp3 converter audio extractor').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Music className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">6. MP4 To MP3 Converter</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">AUDIO EXTRACTOR</span>
                  </div>
                </div>

                <label className="border-2 border-dashed border-cyan-400/40 rounded-xl p-4 text-center block cursor-pointer hover:border-cyan-400 bg-cyan-500/5 transition mb-3">
                  <Download className="w-6 h-6 text-cyan-400 mx-auto mb-1" />
                  <span className="text-xs text-slate-200 font-medium block">Upload Video File (MP4)</span>
                  <input type="file" accept="video/*" className="hidden" onChange={handleMp4Upload} />
                </label>

                {mp3Url && (
                  <a
                    href={mp3Url}
                    download="extracted_audio.mp3"
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1 hover:brightness-110 shadow-lg shadow-cyan-500/20"
                  >
                    🎵 Download MP3 Audio File
                  </a>
                )}
              </div>
            </div>
          )}

          {/* 7. VOCAL REMOVER */}
          {('7. vocal remover karaoke instrumental').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <MicOff className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">7. Vocal Remover</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">KARAOKE ISOLATOR</span>
                  </div>
                </div>

                <label className="border-2 border-dashed border-purple-500/40 rounded-xl p-4 text-center block cursor-pointer hover:border-purple-400 bg-purple-500/5 transition mb-3">
                  <Music className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                  <span className="text-xs text-slate-200 font-medium block">Upload Audio Song (MP3)</span>
                  <input type="file" accept="audio/*" className="hidden" onChange={handleVocalUpload} />
                </label>

                {vocalAudioUrl && (
                  <div className="space-y-2">
                    <audio src={vocalAudioUrl} controls className="w-full h-8" />
                    <button onClick={() => showToast('🎛️ Switched to Instrumental Track')} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-mono font-bold py-2 rounded-xl shadow-lg shadow-cyan-500/20">
                      🎸 Instrumental Only
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 8. TEXT TO PHOTO GENERATOR */}
          {('8. text to photo generator banner').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">8. Text To Photo Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">NEON GRAPHICS</span>
                  </div>
                </div>

                <input
                  type="text"
                  placeholder="Banner Text (e.g. DARAZ SALE)"
                  value={t2pPrompt}
                  onChange={(e) => setT2pPrompt(e.target.value)}
                  className="w-full glass-input rounded-xl p-2 text-xs text-white placeholder-white/40"
                />

                <button onClick={handleGenerateT2p} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl shadow-lg shadow-cyan-500/20">
                  🎨 Generate Cyber Photo
                </button>

                {t2pCanvasUrl && (
                  <div className="space-y-2">
                    <img src={t2pCanvasUrl} alt="Generated" className="w-full rounded-lg border border-white/10" />
                    <a href={t2pCanvasUrl} download="cyber_photo.png" className="w-full bg-white/10 border border-white/15 text-cyan-400 font-mono font-bold text-xs py-2 rounded-xl flex items-center justify-center hover:bg-white/20">
                      💾 Download Photo
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 9. PHOTO TO VIDEO GENERATOR */}
          {('9. photo to video generator slideshow').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <Video className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">9. Photo To Video Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">VIDEO SLIDESHOW</span>
                  </div>
                </div>

                <label className="border-2 border-dashed border-emerald-500/40 rounded-xl p-4 text-center block cursor-pointer hover:border-emerald-400 bg-emerald-500/5 transition mb-3">
                  <Video className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                  <span className="text-xs text-slate-200 font-medium block">Select Photos to Animate</span>
                  <input type="file" accept="image/*" multiple className="hidden" onChange={handleP2vUpload} />
                </label>

                {p2vFiles && (
                  <button onClick={handleRenderP2v} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl shadow-lg shadow-cyan-500/20">
                    🎬 Render & Record Video
                  </button>
                )}

                {p2vDone && (
                  <a href="#" className="w-full mt-2 bg-white/10 border border-white/15 text-cyan-400 font-mono font-bold text-xs py-2 rounded-xl flex items-center justify-center hover:bg-white/20">
                    🎥 Download Video
                  </a>
                )}
              </div>
            </div>
          )}

          {/* 10. QR CODE GENERATOR */}
          {('10. qr code generator barcode url').includes(searchQuery.toLowerCase()) && (
            <div className="glass-card p-5 hover:border-cyan-400/50 hover:shadow-[0_8px_32px_rgba(0,243,255,0.15)] transition-all flex flex-col justify-between hover:-translate-y-1">
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-white">10. QR Code Generator</h3>
                    <span className="text-[10px] text-cyan-400 font-mono tracking-wider">CYBER BARCODE</span>
                  </div>
                </div>

                <input
                  type="text"
                  placeholder="Enter URL or Text"
                  value={qrText}
                  onChange={(e) => setQrText(e.target.value)}
                  className="w-full glass-input rounded-xl p-2 text-xs text-white placeholder-white/40"
                />

                <div className="flex justify-center p-2 bg-white/90 rounded-xl">
                  <canvas ref={qrCanvasRef} width={160} height={160} />
                </div>
              </div>

              <button onClick={downloadQR} className="w-full mt-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-mono font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1 shadow-lg shadow-cyan-500/20">
                <Download className="w-3.5 h-3.5" /> Download QR Code PNG
              </button>
            </div>
          )}

        </div>

        {/* SUPPORT SECTION */}
        <section className="glass-card p-6 mb-10 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-mono font-bold text-base text-white">Support Inbox</h3>
              <p className="text-xs text-white/50">24/7 Official Developer Assistance Channel</p>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between flex-wrap gap-3">
            <div>
              <span className="text-[10px] text-white/40 font-mono block">OFFICIAL SUPPORT EMAIL:</span>
              <span className="text-xs font-mono font-bold text-cyan-400">daraz.bangladesh.shop.com</span>
            </div>
            <button
              onClick={() => { navigator.clipboard.writeText('daraz.bangladesh.shop.com'); showToast('📋 Support Email Copied!'); }}
              className="bg-white/10 border border-white/15 text-white text-xs font-mono font-bold px-4 py-2 rounded-xl hover:bg-white/20 transition flex items-center gap-1.5"
            >
              <Copy className="w-3.5 h-3.5" /> Copy Email
            </button>
          </div>
        </section>

        {/* FOOTER WITH 7 ACCORDION POLICIES */}
        <footer className="border-t border-white/10 pt-8">
          <h3 className="font-mono text-center text-sm font-bold text-white mb-6 tracking-wider">
            LEGAL & REGULATORY POLICIES
          </h3>

          <div className="max-w-3xl mx-auto space-y-3 mb-8">
            {policies.map((policy, idx) => (
              <div key={idx} className="glass-card overflow-hidden transition-all">
                <button
                  onClick={() => togglePolicy(idx)}
                  className="w-full px-5 py-3.5 flex items-center justify-between text-left text-xs font-semibold text-slate-200 hover:text-cyan-400 transition"
                >
                  <span>{policy.title}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${openPolicy === idx ? 'rotate-180 text-cyan-400' : ''}`} />
                </button>
                {openPolicy === idx && (
                  <div className="px-5 py-4 border-t border-white/5 text-xs text-white/60 leading-relaxed bg-white/5">
                    {policy.content}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* HIDDEN ADMIN PANEL BOTTOM */}
          {adminMode && (
            <div className="my-6 p-4 rounded-2xl glass-card neon-border flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-bold">
                <Shield className="w-5 h-5" />
                ADMIN FOOTER COMMAND ACCESS
              </div>
              <button
                onClick={copyCompleteSourceCode}
                className="px-5 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 font-mono font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition"
              >
                📋 COPY COMPLETE HTML SOURCE CODE
              </button>
            </div>
          )}

          <div className="text-center text-[11px] text-slate-500 font-mono pb-8">
            © 2026 Daraz Free Short Link Generator Unlimited • All Rights Reserved.
          </div>
        </footer>

      </div>
    </div>
  );
}
